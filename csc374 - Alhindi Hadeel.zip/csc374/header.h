/*-------------------------------------------------------------------------*
 *---									---*
 *---		header.h						---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1a					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>

// YOUR CODE HERE
	  
extern char**		array;
extern int		arrayLen; 
extern int               strLen; 
extern void               swap(); 
extern void              bubbleSort ();
extern void              quickSort (); 


